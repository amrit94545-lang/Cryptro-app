# Android AIDE & APK Guide
## How to build an APK for Crypto Futures Chart

### Option 1: Direct WebView in Android AIDE (Fastest)
1. Open Android AIDE on your phone.
2. Create a new Project -> "Android App".
3. In `AndroidManifest.xml`, ensure Internet permission is added:
   `<uses-permission android:name="android.permission.INTERNET" />`
4. In `MainActivity.java`, replace the code with:
```java
package com.cryptofutures.chart;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://ais-dev-sqw5wj7ijvmqb5wfw5cqpq-844811311740.us-east1.run.app");
        setContentView(webView);
    }
}
```
5. Tap the "Run" / Play button in AIDE -> It compiles and installs the APK on your phone immediately!

### Option 2: Run with Node.js & Vite
1. Extract this zip.
2. Run `npm install`
3. Run `npm run dev`
