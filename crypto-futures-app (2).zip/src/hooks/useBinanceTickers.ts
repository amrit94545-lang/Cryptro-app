import { useEffect, useState, useRef } from 'react';
import { TickerData } from '../types';

export function useBinanceTickers() {
  const [tickers, setTickers] = useState<Record<string, TickerData>>({});
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);

  // Fetch initial 24h ticker data snapshot
  const fetchSnapshot = async () => {
    try {
      // First try futures 24hr ticker
      let res = await fetch('https://fapi.binance.com/fapi/v1/ticker/24hr', {
        headers: { Accept: 'application/json' },
      }).catch(() => null);

      // Fallback to spot if futures endpoint is blocked by region or CORS
      if (!res || !res.ok) {
        res = await fetch('https://api.binance.com/api/v3/ticker/24hr');
      }

      if (res && res.ok) {
        const data = await res.json();
        const map: Record<string, TickerData> = {};
        const now = Date.now();

        if (Array.isArray(data)) {
          for (const item of data) {
            const symbol = item.symbol;
            map[symbol] = {
              symbol,
              lastPrice: parseFloat(item.lastPrice || '0'),
              priceChange: parseFloat(item.priceChange || '0'),
              priceChangePercent: parseFloat(item.priceChangePercent || '0'),
              highPrice: parseFloat(item.highPrice || '0'),
              lowPrice: parseFloat(item.lowPrice || '0'),
              volume: parseFloat(item.volume || '0'),
              quoteVolume: parseFloat(item.quoteVolume || '0'),
              lastUpdated: now,
            };
          }
          setTickers((prev) => ({ ...prev, ...map }));
          setError(null);
        }
      }
    } catch (err) {
      console.warn('Could not fetch Binance snapshot:', err);
    }
  };

  useEffect(() => {
    fetchSnapshot();
    const interval = setInterval(fetchSnapshot, 15000); // refresh every 15s

    // Connect to Binance Futures Live WebSocket for instant real-time price updates
    const connectWS = () => {
      try {
        const wsUrl = 'wss://fstream.binance.com/ws/!miniTicker@arr';
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          setError(null);
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (Array.isArray(data)) {
              setTickers((prev) => {
                const updated = { ...prev };
                const now = Date.now();
                for (const t of data) {
                  const s = t.s; // symbol
                  const c = parseFloat(t.c); // close / current price
                  const o = parseFloat(t.o); // open
                  const h = parseFloat(t.h); // high
                  const l = parseFloat(t.l); // low
                  const v = parseFloat(t.v); // volume
                  const q = parseFloat(t.q); // quote volume

                  const priceChange = c - o;
                  const priceChangePercent = o > 0 ? ((c - o) / o) * 100 : 0;

                  updated[s] = {
                    symbol: s,
                    lastPrice: c,
                    priceChange,
                    priceChangePercent,
                    highPrice: h,
                    lowPrice: l,
                    volume: v,
                    quoteVolume: q,
                    lastUpdated: now,
                  };
                }
                return updated;
              });
            }
          } catch (e) {
            // ignore parse err
          }
        };

        ws.onerror = () => {
          setIsConnected(false);
        };

        ws.onclose = () => {
          setIsConnected(false);
          // Auto reconnect after 4 seconds
          reconnectTimeoutRef.current = window.setTimeout(connectWS, 4000);
        };
      } catch (e) {
        setIsConnected(false);
      }
    };

    connectWS();

    return () => {
      clearInterval(interval);
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  return { tickers, isConnected, error, refresh: fetchSnapshot };
}
