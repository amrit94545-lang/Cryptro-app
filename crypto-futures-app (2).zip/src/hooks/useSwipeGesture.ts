import React, { useEffect, useRef, useState, useCallback } from 'react';

interface SwipeConfig {
  onSwipeLeft: () => void;  // Next coin
  onSwipeRight: () => void; // Prev coin
  threshold?: number;       // min distance in px
  disabled?: boolean;
}

export function useSwipeGesture({
  onSwipeLeft,
  onSwipeRight,
  threshold = 45,
  disabled = false,
}: SwipeConfig) {
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const [swipeOffset, setSwipeOffset] = useState<number>(0);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const isDraggingRef = useRef(false);

  // Trigger brief mobile vibration if available
  const triggerHaptic = useCallback(() => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(20);
      } catch {
        // ignore
      }
    }
  }, []);

  const handleTouchStart = useCallback(
    (e: TouchEvent | React.TouchEvent) => {
      if (disabled) return;
      const touch = 'touches' in e ? e.touches[0] : (e as unknown as React.TouchEvent).touches[0];
      if (!touch) return;

      touchStartRef.current = {
        x: touch.clientX,
        y: touch.clientY,
        time: Date.now(),
      };
      isDraggingRef.current = true;
    },
    [disabled]
  );

  const handleTouchMove = useCallback(
    (e: TouchEvent | React.TouchEvent) => {
      if (disabled || !isDraggingRef.current || !touchStartRef.current) return;
      const touch = 'touches' in e ? e.touches[0] : (e as unknown as React.TouchEvent).touches[0];
      if (!touch) return;

      const deltaX = touch.clientX - touchStartRef.current.x;
      const deltaY = touch.clientY - touchStartRef.current.y;

      // Only track if horizontal movement dominates
      if (Math.abs(deltaX) > Math.abs(deltaY)) {
        setSwipeOffset(deltaX);
        if (deltaX < -20) setSwipeDirection('left');
        else if (deltaX > 20) setSwipeDirection('right');
        else setSwipeDirection(null);
      }
    },
    [disabled]
  );

  const handleTouchEnd = useCallback(
    (e: TouchEvent | React.TouchEvent) => {
      if (disabled || !isDraggingRef.current || !touchStartRef.current) return;

      const touch = 'changedTouches' in e ? e.changedTouches[0] : (e as unknown as React.TouchEvent).changedTouches[0];
      if (touch) {
        const deltaX = touch.clientX - touchStartRef.current.x;
        const deltaY = touch.clientY - touchStartRef.current.y;
        const timeDiff = Date.now() - touchStartRef.current.time;

        // Valid swipe criteria:
        // 1. Horizontal distance >= threshold OR quick flick (deltaX > 30 and time < 250ms)
        // 2. Horizontal distance > 1.2 * vertical distance (to prevent vertical scroll misfires)
        const isQuickFlick = Math.abs(deltaX) > 30 && timeDiff < 250;
        const isPastThreshold = Math.abs(deltaX) >= threshold;
        const isHorizontal = Math.abs(deltaX) > Math.abs(deltaY) * 1.2;

        if ((isPastThreshold || isQuickFlick) && isHorizontal) {
          if (deltaX < 0) {
            triggerHaptic();
            onSwipeLeft();
          } else {
            triggerHaptic();
            onSwipeRight();
          }
        }
      }

      touchStartRef.current = null;
      isDraggingRef.current = false;
      setSwipeOffset(0);
      setSwipeDirection(null);
    },
    [disabled, threshold, onSwipeLeft, onSwipeRight, triggerHaptic]
  );

  // Keyboard navigation support (ArrowLeft & ArrowRight)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (disabled) return;
      // Don't intercept if typing in an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onSwipeRight(); // Go to previous coin
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onSwipeLeft(); // Go to next coin
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [disabled, onSwipeLeft, onSwipeRight]);

  return {
    swipeDirection,
    swipeOffset,
    touchHandlers: {
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
      onTouchCancel: () => {
        touchStartRef.current = null;
        isDraggingRef.current = false;
        setSwipeOffset(0);
        setSwipeDirection(null);
      },
    },
  };
}
