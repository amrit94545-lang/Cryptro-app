export type CoinCategory = 'all' | 'top' | 'meme' | 'ai' | 'l1_l2' | 'defi' | 'favorites';

export interface CryptoCoin {
  id: string;
  symbol: string;         // e.g. "BTCUSDT"
  baseAsset: string;      // e.g. "BTC"
  quoteAsset: string;     // e.g. "USDT"
  name: string;           // e.g. "Bitcoin"
  tvSymbol: string;       // e.g. "BINANCE:BTCUSDT.P"
  coindcxPair: string;    // e.g. "B-BTC_USDT" (CoinDCX Futures Contract name)
  category: 'top' | 'meme' | 'ai' | 'l1_l2' | 'defi';
  precision: number;      // decimal points for formatting
}

export interface TickerData {
  symbol: string;
  lastPrice: number;
  priceChange: number;
  priceChangePercent: number;
  highPrice: number;
  lowPrice: number;
  volume: number;
  quoteVolume: number;
  lastUpdated: number;
}

export type TimeframeId = '1' | '3' | '5' | '15' | '30' | '60' | '240' | 'D' | 'W';

export interface TimeframeOption {
  id: TimeframeId;
  label: string;
}

export type ChartType = 'candles' | 'heikinashi' | 'line' | 'bars';
export type ChartTheme = 'dark' | 'oled' | 'light';
