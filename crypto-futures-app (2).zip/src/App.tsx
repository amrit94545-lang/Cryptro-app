import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { CryptoCoin, TimeframeId, ChartType, ChartTheme } from './types';
import { FUTURE_COINS, DEFAULT_FAVORITES } from './data/coins';
import { useBinanceTickers } from './hooks/useBinanceTickers';
import { useSwipeGesture } from './hooks/useSwipeGesture';
import { TradingViewChart } from './components/TradingViewChart';
import { HeaderTicker } from './components/HeaderTicker';
import { SwipeOverlay } from './components/SwipeOverlay';
import { CoinDrawer } from './components/CoinDrawer';
import { FavoritesBar } from './components/FavoritesBar';
import { AutoScanModal } from './components/AutoScanModal';
import { ChartSettingsModal } from './components/ChartSettingsModal';
import { DownloadModal } from './components/DownloadModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Settings, ShieldCheck, Zap } from 'lucide-react';

export default function App() {
  // Load custom coins from localStorage
  const [customCoins, setCustomCoins] = useState<CryptoCoin[]>(() => {
    try {
      const saved = localStorage.getItem('coindcx_custom_coins');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Combine default future coins and custom ones
  const allCoins = useMemo(() => {
    return [...FUTURE_COINS, ...customCoins];
  }, [customCoins]);

  // Favorites list
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('coindcx_favorites');
      return saved ? JSON.parse(saved) : DEFAULT_FAVORITES;
    } catch {
      return DEFAULT_FAVORITES;
    }
  });

  // Save favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('coindcx_favorites', JSON.stringify(favorites));
    } catch {
      // ignore
    }
  }, [favorites]);

  // Filter mode for swiping: 'all' or 'favorites'
  const [swipeFilterMode, setSwipeFilterMode] = useState<'all' | 'favorites'>('all');

  // Active Coin Index
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Timeframe, theme, chart type, swipe sensitivity
  const [timeframe, setTimeframe] = useState<TimeframeId>(() => {
    return (localStorage.getItem('coindcx_tf') as TimeframeId) || '15';
  });
  const [chartType, setChartType] = useState<ChartType>('candles');
  const [theme, setTheme] = useState<ChartTheme>('dark');
  const [swipeSensitivity, setSwipeSensitivity] = useState<'high' | 'medium' | 'low'>('medium');

  // Modals & Drawers
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [drawerCategory, setDrawerCategory] = useState<'all' | 'top' | 'meme' | 'ai' | 'l1_l2' | 'defi' | 'favorites'>('all');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAutoScanModalOpen, setIsAutoScanModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Auto-Scan Slideshow State
  const [isAutoScanActive, setIsAutoScanActive] = useState(false);
  const [autoScanInterval, setAutoScanInterval] = useState(10);
  const [autoScanSecondsLeft, setAutoScanSecondsLeft] = useState(10);
  const [autoScanOnlyFavorites, setAutoScanOnlyFavorites] = useState(false);

  // Real-time tickers
  const { tickers } = useBinanceTickers();

  // Favorite coins array
  const favoriteCoinsList = useMemo(() => {
    return allCoins.filter((c) => favorites.includes(c.symbol));
  }, [allCoins, favorites]);

  // Active playlist depending on swipeFilterMode and autoScanOnlyFavorites
  const activePlaylist = useMemo(() => {
    if (swipeFilterMode === 'favorites' || autoScanOnlyFavorites) {
      return favoriteCoinsList.length > 0 ? favoriteCoinsList : allCoins;
    }
    return allCoins;
  }, [allCoins, swipeFilterMode, autoScanOnlyFavorites, favoriteCoinsList]);

  // Safe active coin
  const activeCoin = activePlaylist[currentIndex % activePlaylist.length] || allCoins[0];

  // Open drawer specifically to favorites or all
  const handleOpenFavoritesDrawer = () => {
    setDrawerCategory('favorites');
    setIsDrawerOpen(true);
  };

  const handleOpenAllDrawer = () => {
    setDrawerCategory('all');
    setIsDrawerOpen(true);
  };

  // Navigation handlers
  const handleNextCoin = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % activePlaylist.length);
  }, [activePlaylist.length]);

  const handlePrevCoin = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + activePlaylist.length) % activePlaylist.length);
  }, [activePlaylist.length]);

  const handleSelectCoin = useCallback((coin: CryptoCoin) => {
    const idx = activePlaylist.findIndex((c) => c.symbol === coin.symbol);
    if (idx !== -1) {
      setCurrentIndex(idx);
    } else {
      // If not in current playlist, switch to all mode and select
      setSwipeFilterMode('all');
      setAutoScanOnlyFavorites(false);
      const allIdx = allCoins.findIndex((c) => c.symbol === coin.symbol);
      if (allIdx !== -1) {
        setCurrentIndex(allIdx);
      }
    }
  }, [activePlaylist, allCoins]);

  // Threshold in px for swipe
  const thresholdPx = swipeSensitivity === 'high' ? 25 : swipeSensitivity === 'low' ? 75 : 45;

  // Touch Swipe Gesture Hook
  const { touchHandlers } = useSwipeGesture({
    onSwipeLeft: handleNextCoin,
    onSwipeRight: handlePrevCoin,
    threshold: thresholdPx,
    disabled: isDrawerOpen || isSettingsOpen || isAutoScanModalOpen,
  });

  // Toggle favorite
  const handleToggleFavorite = (symbol: string) => {
    setFavorites((prev) =>
      prev.includes(symbol) ? prev.filter((s) => s !== symbol) : [...prev, symbol]
    );
  };

  // Add custom coin
  const handleAddCustomCoin = (symbol: string) => {
    const cleanSym = symbol.replace(/[^A-Z0-9]/g, '').toUpperCase();
    const finalSym = cleanSym.endsWith('USDT') ? cleanSym : `${cleanSym}USDT`;
    const base = finalSym.replace('USDT', '');

    if (allCoins.some((c) => c.symbol === finalSym)) {
      const found = allCoins.find((c) => c.symbol === finalSym);
      if (found) handleSelectCoin(found);
      return;
    }

    const newCoin: CryptoCoin = {
      id: base.toLowerCase(),
      symbol: finalSym,
      baseAsset: base,
      quoteAsset: 'USDT',
      name: `${base} Futures`,
      tvSymbol: `BINANCE:${finalSym}.P`,
      coindcxPair: `B-${base}_USDT`,
      category: 'top',
      precision: 4,
    };

    const updated = [...customCoins, newCoin];
    setCustomCoins(updated);
    try {
      localStorage.setItem('coindcx_custom_coins', JSON.stringify(updated));
    } catch {
      // ignore
    }
    // Select the new coin immediately
    setCurrentIndex(allCoins.length);
  };

  // Auto-Scan interval ticker
  useEffect(() => {
    if (!isAutoScanActive) return;

    setAutoScanSecondsLeft(autoScanInterval);
    const interval = setInterval(() => {
      setAutoScanSecondsLeft((prev) => {
        if (prev <= 1) {
          handleNextCoin();
          return autoScanInterval;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isAutoScanActive, autoScanInterval, handleNextCoin]);

  // Save timeframe
  const handleSelectTimeframe = (tf: TimeframeId) => {
    setTimeframe(tf);
    try {
      localStorage.setItem('coindcx_tf', tf);
    } catch {
      // ignore
    }
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const prevCoin = activePlaylist[(currentIndex - 1 + activePlaylist.length) % activePlaylist.length];
  const nextCoin = activePlaylist[(currentIndex + 1) % activePlaylist.length];
  const isFav = favorites.includes(activeCoin.symbol);

  return (
    <div
      id="crypto-futures-swipe-app"
      className={`relative w-full h-full flex flex-col overflow-hidden select-none ${
        theme === 'oled' ? 'bg-black' : 'bg-[#090d16]'
      }`}
    >
      {/* Top Header & Real-time Ticker Bar */}
      <HeaderTicker
        coin={activeCoin}
        ticker={tickers[activeCoin.symbol]}
        timeframe={timeframe}
        onSelectTimeframe={handleSelectTimeframe}
        isFavorite={isFav}
        onToggleFavorite={() => handleToggleFavorite(activeCoin.symbol)}
        onOpenDrawer={handleOpenAllDrawer}
        onOpenFavorites={handleOpenFavoritesDrawer}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
        favoritesCount={favorites.length}
        currentIndex={currentIndex}
        totalCoins={activePlaylist.length}
        isAutoScanActive={isAutoScanActive}
        onToggleAutoScan={() => setIsAutoScanModalOpen(true)}
        autoScanSecondsLeft={autoScanSecondsLeft}
      />

      {/* Quick Access Favorites Watchlist Bar */}
      <FavoritesBar
        favoriteCoins={favoriteCoinsList}
        activeCoin={activeCoin}
        onSelectCoin={handleSelectCoin}
        tickers={tickers}
        onOpenFavoritesDrawer={handleOpenFavoritesDrawer}
        onOpenAllCoinsDrawer={handleOpenAllDrawer}
        swipeFilterMode={swipeFilterMode}
        onToggleSwipeFilterMode={setSwipeFilterMode}
        totalAllCoins={allCoins.length}
      />

      {/* Main Chart Stage */}
      <main className="relative flex-1 w-full h-full flex flex-col overflow-hidden">
        {/* The Live TradingView Chart */}
        <TradingViewChart
          coin={activeCoin}
          timeframe={timeframe}
          chartType={chartType}
          theme={theme}
          isFullscreen={isFullscreen}
          onToggleFullscreen={toggleFullscreen}
        />

        {/* Swipe Interaction Overlay (Side Arrows & Bottom Gesture Bar) */}
        <SwipeOverlay
          prevCoin={prevCoin}
          nextCoin={nextCoin}
          prevTicker={tickers[prevCoin?.symbol || '']}
          nextTicker={tickers[nextCoin?.symbol || '']}
          currentIndex={currentIndex}
          totalCoins={activePlaylist.length}
          onPrev={handlePrevCoin}
          onNext={handleNextCoin}
          touchHandlers={touchHandlers}
        />

        {/* Floating Quick Settings trigger button */}
        <button
          id="btn-settings-trigger"
          onClick={() => setIsSettingsOpen(true)}
          title="Chart Settings & Guide"
          className="absolute top-2 right-2 z-20 p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/60 backdrop-blur-md shadow-lg transition active:scale-95 cursor-pointer"
        >
          <Settings className="w-4 h-4" />
        </button>
      </main>

      {/* Slide-over Coin List & Search Drawer */}
      <CoinDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        coins={allCoins}
        activeCoin={activeCoin}
        onSelectCoin={handleSelectCoin}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
        tickers={tickers}
        onAddCustomCoin={handleAddCustomCoin}
        initialCategory={drawerCategory}
      />

      {/* Auto-Scan Slideshow Config Modal */}
      <AutoScanModal
        isOpen={isAutoScanModalOpen}
        onClose={() => setIsAutoScanModalOpen(false)}
        isActive={isAutoScanActive}
        intervalSeconds={autoScanInterval}
        onSelectInterval={setAutoScanInterval}
        onlyFavorites={autoScanOnlyFavorites}
        onToggleOnlyFavorites={setAutoScanOnlyFavorites}
        favoritesCount={favorites.length}
        onStart={() => setIsAutoScanActive(true)}
        onStop={() => setIsAutoScanActive(false)}
      />

      {/* Settings Modal */}
      <ChartSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={theme}
        onSelectTheme={setTheme}
        chartType={chartType}
        onSelectChartType={setChartType}
        swipeSensitivity={swipeSensitivity}
        onSelectSensitivity={setSwipeSensitivity}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Download & APK Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* Offline Status Toast */}
      <OfflineIndicator />
    </div>
  );
}
