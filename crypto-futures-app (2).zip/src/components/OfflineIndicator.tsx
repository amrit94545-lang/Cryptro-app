import React, { useState, useEffect } from 'react';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed bottom-14 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-500/95 text-slate-950 px-3 py-1.5 text-xs font-semibold shadow-xl backdrop-blur-xs">
      <WifiOff className="w-4 h-4 animate-pulse" />
      <span>Offline Mode &bull; Showing cached tickers</span>
    </div>
  );
};
