import React from 'react';
import { CryptoCoin, TickerData } from '../types';
import { Star, Sliders, ChevronRight, Plus, Eye } from 'lucide-react';

interface FavoritesBarProps {
  favoriteCoins: CryptoCoin[];
  activeCoin: CryptoCoin;
  onSelectCoin: (coin: CryptoCoin) => void;
  tickers: Record<string, TickerData>;
  onOpenFavoritesDrawer: () => void;
  onOpenAllCoinsDrawer: () => void;
  swipeFilterMode: 'all' | 'favorites';
  onToggleSwipeFilterMode: (mode: 'all' | 'favorites') => void;
  totalAllCoins: number;
}

export const FavoritesBar: React.FC<FavoritesBarProps> = ({
  favoriteCoins,
  activeCoin,
  onSelectCoin,
  tickers,
  onOpenFavoritesDrawer,
  onOpenAllCoinsDrawer,
  swipeFilterMode,
  onToggleSwipeFilterMode,
  totalAllCoins,
}) => {
  const formatPrice = (val?: number, precision = 4) => {
    if (val === undefined || isNaN(val)) return '---';
    if (val < 0.001) return val.toFixed(precision);
    if (val < 1) return val.toFixed(4);
    if (val < 10) return val.toFixed(3);
    return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="bg-[#0e1626] border-b border-slate-800/90 px-2 sm:px-3 py-1 flex items-center justify-between gap-2 select-none overflow-x-auto text-xs shrink-0 z-20">
      {/* Left: Mode Toggle (All vs Favorites Swipe Mode) */}
      <div className="flex items-center gap-1 shrink-0">
        <div className="flex items-center bg-slate-900/90 rounded-lg p-0.5 border border-slate-750">
          <button
            onClick={() => onToggleSwipeFilterMode('all')}
            title="Swipe through all 200+ future coins"
            className={`px-2 py-0.5 rounded-md font-semibold text-[11px] transition cursor-pointer flex items-center gap-1 ${
              swipeFilterMode === 'all'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>All</span>
            <span className="text-[10px] opacity-75 font-mono">({totalAllCoins})</span>
          </button>

          <button
            onClick={() => onToggleSwipeFilterMode('favorites')}
            title="Swipe ONLY between your starred favorite coins"
            className={`px-2 py-0.5 rounded-md font-semibold text-[11px] transition cursor-pointer flex items-center gap-1 ${
              swipeFilterMode === 'favorites'
                ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40 shadow-xs'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>Watchlist</span>
            <span className="text-[10px] font-mono">({favoriteCoins.length})</span>
          </button>
        </div>

        <div className="h-4 w-px bg-slate-800 mx-1 hidden xs:block" />
      </div>

      {/* Center: Scrollable Favorite Coin Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar flex-1 py-0.5">
        {favoriteCoins.length === 0 ? (
          <div className="flex items-center gap-2 text-slate-400 text-[11px] px-2 py-0.5">
            <span>No favorites yet &bull;</span>
            <button
              onClick={onOpenAllCoinsDrawer}
              className="text-amber-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3" /> Star coins to add
            </button>
          </div>
        ) : (
          favoriteCoins.map((coin) => {
            const ticker = tickers[coin.symbol];
            const isActive = activeCoin.symbol === coin.symbol;
            const isPositive = (ticker?.priceChangePercent ?? 0) >= 0;

            return (
              <button
                key={coin.symbol}
                onClick={() => onSelectCoin(coin)}
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-mono border transition shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500/20 border-amber-500/60 text-white shadow-xs font-bold'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Star
                  className={`w-2.5 h-2.5 ${
                    isActive ? 'fill-amber-400 text-amber-400' : 'fill-amber-400/70 text-amber-400/70'
                  }`}
                />
                <span className="font-sans font-bold">{coin.baseAsset}</span>
                <span className="text-slate-200">
                  ${formatPrice(ticker?.lastPrice, coin.precision)}
                </span>
                <span
                  className={`text-[10px] font-semibold ${
                    isPositive ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isPositive ? '+' : ''}
                  {ticker?.priceChangePercent?.toFixed(1) ?? '0.0'}%
                </span>
              </button>
            );
          })
        )}
      </div>

      {/* Right: Open Full Favorites Drawer Button */}
      <div className="shrink-0 flex items-center gap-1 pl-1">
        <button
          id="btn-view-all-favorites"
          onClick={onOpenFavoritesDrawer}
          title="View full Favorites list & manage coins"
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border border-slate-800 text-[11px] font-medium transition cursor-pointer"
        >
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span className="hidden sm:inline">Manage List</span>
          <span className="sm:hidden">List</span>
          <ChevronRight className="w-3 h-3 opacity-60" />
        </button>
      </div>
    </div>
  );
};
