import React, { memo, useState, useEffect } from 'react';
import { CryptoCoin, TimeframeId, ChartType, ChartTheme } from '../types';
import { Maximize2, Minimize2, RefreshCw } from 'lucide-react';

interface TradingViewChartProps {
  coin: CryptoCoin;
  timeframe: TimeframeId;
  chartType?: ChartType;
  theme?: ChartTheme;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
}

const CHART_STYLE_MAP: Record<ChartType, string> = {
  candles: '1',
  bars: '0',
  line: '2',
  heikinashi: '8',
};

export const TradingViewChart: React.FC<TradingViewChartProps> = memo(
  ({
    coin,
    timeframe,
    chartType = 'candles',
    theme = 'dark',
    isFullscreen = false,
    onToggleFullscreen,
  }) => {
    const [isLoading, setIsLoading] = useState(true);
    const [reloadKey, setReloadKey] = useState(0);

    // When coin or timeframe changes, show quick loading overlay
    useEffect(() => {
      setIsLoading(true);
      const timer = setTimeout(() => setIsLoading(false), 500);
      return () => clearTimeout(timer);
    }, [coin.symbol, timeframe, chartType, reloadKey]);

    const styleCode = CHART_STYLE_MAP[chartType] || '1';
    const tvTheme = theme === 'light' ? 'light' : 'dark';
    const bgColor = theme === 'oled' ? '000000' : '090d16';

    // Construct high-performance, official TradingView responsive widget URL
    // Symbol formats: BINANCE:BTCUSDT.P (perpetual futures) or BINANCE:BTCUSDT
    const primarySymbol = coin.tvSymbol || `BINANCE:${coin.symbol}.P`;
    
    // Set parameters tailored for mobile trading & fast scanning
    const widgetUrl = new URL('https://s.tradingview.com/widgetembed/');
    widgetUrl.searchParams.set('frameElementId', `tv_embed_${coin.symbol}`);
    widgetUrl.searchParams.set('symbol', primarySymbol);
    widgetUrl.searchParams.set('interval', timeframe);
    widgetUrl.searchParams.set('symboledit', '0');
    widgetUrl.searchParams.set('saveimage', '1');
    widgetUrl.searchParams.set('toolbarbg', bgColor);
    widgetUrl.searchParams.set('theme', tvTheme);
    widgetUrl.searchParams.set('style', styleCode);
    widgetUrl.searchParams.set('timezone', 'Asia/Kolkata'); // Standard Indian time for CoinDCX traders, displays clearly on chart
    widgetUrl.searchParams.set('withdateranges', '1');
    widgetUrl.searchParams.set('showpopupbutton', '0');
    widgetUrl.searchParams.set('hideideas', '1');
    widgetUrl.searchParams.set('studies', JSON.stringify(['STD;EMA'])); // Default 1 EMA line for quick trend analysis
    widgetUrl.searchParams.set('locale', 'en');

    return (
      <div
        id="tradingview-chart-container"
        className="relative w-full h-full flex-1 bg-[#090d16] flex flex-col overflow-hidden"
      >
        {/* Loading Indicator */}
        {isLoading && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#090d16]/90 backdrop-blur-xs transition-opacity duration-200 pointer-events-none">
            <div className="relative flex items-center justify-center mb-3">
              <div className="w-12 h-12 border-2 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
              <span className="absolute text-[11px] font-bold text-emerald-400">
                {coin.baseAsset}
              </span>
            </div>
            <div className="text-xs font-medium text-slate-300 tracking-wide">
              Loading {coin.symbol} Futures Chart...
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Binance Perpetual &bull; CoinDCX Live
            </div>
          </div>
        )}

        {/* The Live TradingView iFrame */}
        <iframe
          key={`${coin.symbol}-${timeframe}-${chartType}-${theme}-${reloadKey}`}
          id={`tv-iframe-${coin.symbol}`}
          title={`${coin.name} Live Trading Chart`}
          src={widgetUrl.toString()}
          className="w-full h-full border-0 flex-1 bg-[#090d16]"
          allow="fullscreen"
          onLoad={() => setIsLoading(false)}
        />

        {/* Minimal chart overlay actions (Fullscreen & Quick Refresh) */}
        <div className="absolute bottom-2 right-2 z-10 flex items-center gap-1.5 opacity-70 hover:opacity-100 transition-opacity">
          <button
            id="btn-refresh-chart"
            onClick={() => setReloadKey((k) => k + 1)}
            title="Reload Chart"
            className="p-1.5 rounded-md bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs border border-slate-700/50 backdrop-blur-sm cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          {onToggleFullscreen && (
            <button
              id="btn-fullscreen-toggle"
              onClick={onToggleFullscreen}
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Chart'}
              className="p-1.5 rounded-md bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs border border-slate-700/50 backdrop-blur-sm cursor-pointer"
            >
              {isFullscreen ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>
    );
  }
);
