import React, { useState, useMemo } from 'react';
import { CryptoCoin, CoinCategory, TickerData } from '../types';
import { CATEGORIES } from '../data/coins';
import {
  X,
  Search,
  Star,
  Flame,
  Sparkles,
  Cpu,
  Layers,
  TrendingUp,
  Coins,
  ArrowUpDown,
  Plus,
} from 'lucide-react';

interface CoinDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  coins: CryptoCoin[];
  activeCoin: CryptoCoin;
  onSelectCoin: (coin: CryptoCoin) => void;
  favorites: string[];
  onToggleFavorite: (symbol: string) => void;
  tickers: Record<string, TickerData>;
  onAddCustomCoin: (symbol: string) => void;
  initialCategory?: CoinCategory;
}

type SortMode = 'default' | 'gainers' | 'losers' | 'volume';

export const CoinDrawer: React.FC<CoinDrawerProps> = ({
  isOpen,
  onClose,
  coins,
  activeCoin,
  onSelectCoin,
  favorites,
  onToggleFavorite,
  tickers,
  onAddCustomCoin,
  initialCategory = 'all',
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CoinCategory>(initialCategory);
  const [sortMode, setSortMode] = useState<SortMode>('default');
  const [customInput, setCustomInput] = useState('');
  const [showAddCustom, setShowAddCustom] = useState(false);

  // When drawer opens, reset to initialCategory if specified
  React.useEffect(() => {
    if (isOpen) {
      setSelectedCategory(initialCategory);
      setSearch('');
    }
  }, [isOpen, initialCategory]);

  // Filter & sort coins
  const filteredCoins = useMemo(() => {
    let list = coins.filter((coin) => {
      // Category filter
      if (selectedCategory === 'favorites') {
        if (!favorites.includes(coin.symbol)) return false;
      } else if (selectedCategory !== 'all') {
        if (coin.category !== selectedCategory) return false;
      }

      // Search filter
      if (search.trim()) {
        const query = search.toLowerCase();
        return (
          coin.symbol.toLowerCase().includes(query) ||
          coin.name.toLowerCase().includes(query) ||
          coin.baseAsset.toLowerCase().includes(query) ||
          coin.coindcxPair.toLowerCase().includes(query)
        );
      }

      return true;
    });

    // Sort
    if (sortMode === 'gainers') {
      list = [...list].sort(
        (a, b) => (tickers[b.symbol]?.priceChangePercent ?? 0) - (tickers[a.symbol]?.priceChangePercent ?? 0)
      );
    } else if (sortMode === 'losers') {
      list = [...list].sort(
        (a, b) => (tickers[a.symbol]?.priceChangePercent ?? 0) - (tickers[b.symbol]?.priceChangePercent ?? 0)
      );
    } else if (sortMode === 'volume') {
      list = [...list].sort(
        (a, b) => (tickers[b.symbol]?.quoteVolume ?? 0) - (tickers[a.symbol]?.quoteVolume ?? 0)
      );
    }

    return list;
  }, [coins, selectedCategory, search, favorites, sortMode, tickers]);

  if (!isOpen) return null;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customInput.trim()) {
      onAddCustomCoin(customInput.trim().toUpperCase());
      setCustomInput('');
      setShowAddCustom(false);
    }
  };

  const getCategoryIcon = (catId: string) => {
    switch (catId) {
      case 'favorites':
        return <Star className="w-3.5 h-3.5" />;
      case 'top':
        return <Flame className="w-3.5 h-3.5" />;
      case 'meme':
        return <Sparkles className="w-3.5 h-3.5" />;
      case 'ai':
        return <Cpu className="w-3.5 h-3.5" />;
      case 'l1_l2':
        return <Layers className="w-3.5 h-3.5" />;
      case 'defi':
        return <TrendingUp className="w-3.5 h-3.5" />;
      default:
        return <Coins className="w-3.5 h-3.5" />;
    }
  };

  const formatPrice = (val?: number, precision = 4) => {
    if (val === undefined || isNaN(val)) return '---';
    if (val < 0.001) return val.toFixed(precision);
    if (val < 1) return val.toFixed(4);
    if (val < 10) return val.toFixed(3);
    return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs select-none">
      {/* Click backdrop to close */}
      <div className="flex-1" onClick={onClose} />

      {/* Drawer content */}
      <div className="w-full max-w-md h-full bg-[#0b1120] border-l border-slate-800 flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Futures Coins</span>
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                CoinDCX & Binance
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Swipe or tap any coin to load live chart
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-950/40">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search coin (e.g. BTC, PEPE, SUI)..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto mt-2.5 pb-1 no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as CoinCategory)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs whitespace-nowrap transition cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {getCategoryIcon(cat.id)}
                <span>{cat.label}</span>
                {cat.id === 'favorites' && (
                  <span className="ml-0.5 text-[10px] opacity-75">
                    ({favorites.length})
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Sorting Row */}
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/60 text-xs">
            <span className="text-slate-400 text-[11px] flex items-center gap-1">
              <ArrowUpDown className="w-3 h-3 text-slate-500" />
              Sort:
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSortMode('default')}
                className={`px-2 py-0.5 rounded text-[11px] transition cursor-pointer ${
                  sortMode === 'default'
                    ? 'bg-slate-800 text-emerald-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Default
              </button>
              <button
                onClick={() => setSortMode('gainers')}
                className={`px-2 py-0.5 rounded text-[11px] transition cursor-pointer ${
                  sortMode === 'gainers'
                    ? 'bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Gainers ↑
              </button>
              <button
                onClick={() => setSortMode('losers')}
                className={`px-2 py-0.5 rounded text-[11px] transition cursor-pointer ${
                  sortMode === 'losers'
                    ? 'bg-rose-500/20 text-rose-400 font-semibold border border-rose-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Losers ↓
              </button>
              <button
                onClick={() => setSortMode('volume')}
                className={`px-2 py-0.5 rounded text-[11px] transition cursor-pointer ${
                  sortMode === 'volume'
                    ? 'bg-blue-500/20 text-blue-400 font-semibold border border-blue-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Vol
              </button>
            </div>
          </div>
        </div>

        {/* Watchlist Info Banner if favorites category is active */}
        {selectedCategory === 'favorites' && (
          <div className="mx-3 mt-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/25 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400 shrink-0" />
              <span className="text-amber-200 font-medium">
                Watchlist ({favorites.length} Coins)
              </span>
            </div>
            <span className="text-[11px] text-amber-300/80">
              Tap ★ on any coin to add/remove
            </span>
          </div>
        )}

        {/* Coin List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/50 p-2">
          {filteredCoins.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              {selectedCategory === 'favorites'
                ? 'No favorite coins starred yet. Tap the star icon on any coin to add it to your watchlist!'
                : 'No matching future coins found.'}
            </div>
          ) : (
            filteredCoins.map((coin) => {
              const ticker = tickers[coin.symbol];
              const isFav = favorites.includes(coin.symbol);
              const isActive = activeCoin.symbol === coin.symbol;
              const isPositive = (ticker?.priceChangePercent ?? 0) >= 0;

              return (
                <div
                  key={coin.symbol}
                  onClick={() => {
                    onSelectCoin(coin);
                    onClose();
                  }}
                  className={`flex items-center justify-between p-2.5 rounded-lg transition group cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/15 border border-emerald-500/30'
                      : 'hover:bg-slate-800/60'
                  }`}
                >
                  {/* Left: Star + Symbol + CoinDCX Pair */}
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(coin.symbol);
                      }}
                      className="p-1 rounded text-slate-500 hover:text-amber-400 transition"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          isFav ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                        }`}
                      />
                    </button>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-white">
                          {coin.baseAsset}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          /USDT
                        </span>
                        {isActive && (
                          <span className="px-1 text-[9px] bg-emerald-500 text-slate-950 font-bold rounded">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {coin.name} &bull;{' '}
                        <span className="text-slate-500 font-mono">
                          {coin.coindcxPair}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Price & 24h Change */}
                  <div className="text-right shrink-0">
                    <div className="font-mono text-sm font-semibold text-white">
                      ${formatPrice(ticker?.lastPrice, coin.precision)}
                    </div>
                    <div
                      className={`text-xs font-mono font-medium flex items-center justify-end ${
                        isPositive ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isPositive ? '+' : ''}
                      {ticker?.priceChangePercent?.toFixed(2) ?? '0.00'}%
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer: Add Custom Coin */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/60">
          {showAddCustom ? (
            <form onSubmit={handleAddSubmit} className="flex items-center gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="e.g. ONDOUSDT"
                className="flex-1 bg-slate-900 border border-slate-700 rounded-md px-3 py-1.5 text-xs text-white uppercase focus:outline-none focus:border-emerald-500"
                autoFocus
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-md transition cursor-pointer"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowAddCustom(false)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <button
              onClick={() => setShowAddCustom(true)}
              className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white text-xs font-medium border border-slate-800 transition cursor-pointer"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Add Custom Future Coin Pair</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
