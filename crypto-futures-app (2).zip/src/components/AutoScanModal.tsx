import React from 'react';
import { X, Play, Square, Timer, Star } from 'lucide-react';

interface AutoScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  isActive: boolean;
  intervalSeconds: number;
  onSelectInterval: (seconds: number) => void;
  onlyFavorites: boolean;
  onToggleOnlyFavorites: (onlyFav: boolean) => void;
  favoritesCount: number;
  onStart: () => void;
  onStop: () => void;
}

const INTERVALS = [5, 10, 15, 30, 60];

export const AutoScanModal: React.FC<AutoScanModalProps> = ({
  isOpen,
  onClose,
  isActive,
  intervalSeconds,
  onSelectInterval,
  onlyFavorites,
  onToggleOnlyFavorites,
  favoritesCount,
  onStart,
  onStop,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 select-none">
      <div className="w-full max-w-sm bg-[#0b1120] border border-slate-800 rounded-2xl p-5 shadow-2xl animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Timer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Auto-Scan Slideshow</h3>
              <p className="text-xs text-slate-400">Hands-free automatic chart switching</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interval Selection */}
        <div className="mt-4">
          <label className="text-xs font-semibold text-slate-300 block mb-2">
            Switch Chart Every:
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {INTERVALS.map((sec) => (
              <button
                key={sec}
                onClick={() => onSelectInterval(sec)}
                className={`py-2 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                  intervalSeconds === sec
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>
        </div>

        {/* Scan Target: All Coins vs Only Favorites */}
        <div className="mt-4 p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <label className="flex items-center justify-between cursor-pointer">
            <div className="flex items-center gap-2">
              <Star
                className={`w-4 h-4 ${
                  onlyFavorites ? 'fill-amber-400 text-amber-400' : 'text-slate-500'
                }`}
              />
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  Only Starred Watchlist
                </div>
                <div className="text-[11px] text-slate-400">
                  Cycle through your {favoritesCount} favorites only
                </div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={onlyFavorites}
              onChange={(e) => onToggleOnlyFavorites(e.target.checked)}
              disabled={favoritesCount === 0}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
          </label>
        </div>

        {/* Actions */}
        <div className="mt-5 flex items-center gap-2">
          {isActive ? (
            <button
              onClick={() => {
                onStop();
                onClose();
              }}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm transition shadow-lg cursor-pointer"
            >
              <Square className="w-4 h-4 fill-white" />
              <span>Stop Auto-Scan</span>
            </button>
          ) : (
            <button
              onClick={() => {
                onStart();
                onClose();
              }}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition shadow-lg cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Start Auto-Scan ({intervalSeconds}s)</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm transition cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
