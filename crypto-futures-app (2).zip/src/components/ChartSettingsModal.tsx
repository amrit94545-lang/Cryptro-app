import React from 'react';
import { ChartType, ChartTheme } from '../types';
import { X, Settings, Moon, Sun, Smartphone, HelpCircle, Palette } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface ChartSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ChartTheme;
  onSelectTheme: (t: ChartTheme) => void;
  chartType: ChartType;
  onSelectChartType: (ct: ChartType) => void;
  swipeSensitivity: 'high' | 'medium' | 'low';
  onSelectSensitivity: (s: 'high' | 'medium' | 'low') => void;
  onOpenDownload?: () => void;
}

export const ChartSettingsModal: React.FC<ChartSettingsModalProps> = ({
  isOpen,
  onClose,
  theme,
  onSelectTheme,
  chartType,
  onSelectChartType,
  swipeSensitivity,
  onSelectSensitivity,
  onOpenDownload,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 select-none">
      <div className="w-full max-w-sm bg-[#0b1120] border border-slate-800 rounded-2xl p-5 shadow-2xl animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-base text-white">Chart & App Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs">
          {/* Theme Selector */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1.5 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-slate-400" />
              Theme & Contrast
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => onSelectTheme('dark')}
                className={`py-2 px-3 rounded-lg font-medium border text-center transition cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-slate-800 border-emerald-500 text-white shadow-xs'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Dark Slate
              </button>
              <button
                onClick={() => onSelectTheme('oled')}
                className={`py-2 px-3 rounded-lg font-medium border text-center transition cursor-pointer ${
                  theme === 'oled'
                    ? 'bg-black border-emerald-500 text-white shadow-xs'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                OLED Pure
              </button>
              <button
                onClick={() => onSelectTheme('light')}
                className={`py-2 px-3 rounded-lg font-medium border text-center transition cursor-pointer ${
                  theme === 'light'
                    ? 'bg-slate-200 border-emerald-500 text-slate-900 shadow-xs'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Light
              </button>
            </div>
          </div>

          {/* Chart Style */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1.5">
              Candle Style
            </label>
            <div className="grid grid-cols-4 gap-1.5 font-mono">
              {(['candles', 'heikinashi', 'line', 'bars'] as ChartType[]).map((ct) => (
                <button
                  key={ct}
                  onClick={() => onSelectChartType(ct)}
                  className={`py-1.5 rounded-lg text-[11px] capitalize border transition cursor-pointer ${
                    chartType === ct
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500 font-bold'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {ct === 'heikinashi' ? 'H.Ashi' : ct}
                </button>
              ))}
            </div>
          </div>

          {/* Swipe Sensitivity */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1.5">
              Mobile Swipe Sensitivity
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['high', 'medium', 'low'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => onSelectSensitivity(s)}
                  className={`py-1.5 rounded-lg capitalize border transition cursor-pointer ${
                    swipeSensitivity === s
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500 font-bold'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Guide */}
          <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800/80 leading-relaxed text-slate-300 space-y-1.5">
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <HelpCircle className="w-4 h-4" />
              <span>CoinDCX Trader Guide</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Screen te <strong className="text-slate-200">Left ya Right swipe</strong> karo to jump to next/prev future coin chart.
            </p>
            <p className="text-[11px] text-slate-400">
              Live candles dekho, trend analysis karo, te apne <strong className="text-slate-200">CoinDCX App</strong> ch order execute karo.
            </p>
          </div>

          {/* PWA Install & Download Modal trigger */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Install to Home Screen:</span>
              <PWAInstallButton />
            </div>
            {onOpenDownload && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDownload();
                }}
                className="w-full py-2 px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/35 text-cyan-300 font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Download App / APK / Code (.ZIP)</span>
              </button>
            )}
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold text-xs transition cursor-pointer"
        >
          Done
        </button>
      </div>
    </div>
  );
};
