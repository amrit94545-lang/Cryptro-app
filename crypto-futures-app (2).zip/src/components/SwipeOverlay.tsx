import React from 'react';
import { CryptoCoin, TickerData } from '../types';
import { ChevronLeft, ChevronRight, Hand } from 'lucide-react';

interface SwipeOverlayProps {
  prevCoin?: CryptoCoin;
  nextCoin?: CryptoCoin;
  prevTicker?: TickerData;
  nextTicker?: TickerData;
  currentIndex: number;
  totalCoins: number;
  onPrev: () => void;
  onNext: () => void;
  touchHandlers: {
    onTouchStart: (e: React.TouchEvent) => void;
    onTouchMove: (e: React.TouchEvent) => void;
    onTouchEnd: (e: React.TouchEvent) => void;
    onTouchCancel: () => void;
  };
}

export const SwipeOverlay: React.FC<SwipeOverlayProps> = ({
  prevCoin,
  nextCoin,
  prevTicker,
  nextTicker,
  currentIndex,
  totalCoins,
  onPrev,
  onNext,
  touchHandlers,
}) => {
  return (
    <>
      {/* Floating Left Arrow (Previous Coin) */}
      <button
        id="btn-prev-coin"
        onClick={onPrev}
        title={prevCoin ? `Previous: ${prevCoin.symbol}` : 'Previous coin'}
        className="absolute left-2 top-1/2 -translate-y-1/2 z-20 group flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 shadow-xl backdrop-blur-md transition-all active:scale-95 cursor-pointer"
      >
        <ChevronLeft className="w-5 h-5 text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
        {prevCoin && (
          <div className="hidden sm:flex flex-col text-left text-[11px] leading-tight">
            <span className="font-bold text-white">{prevCoin.baseAsset}</span>
            <span
              className={`text-[10px] font-mono ${
                (prevTicker?.priceChangePercent ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {(prevTicker?.priceChangePercent ?? 0) >= 0 ? '+' : ''}
              {prevTicker?.priceChangePercent?.toFixed(1) ?? '0.0'}%
            </span>
          </div>
        )}
      </button>

      {/* Floating Right Arrow (Next Coin) */}
      <button
        id="btn-next-coin"
        onClick={onNext}
        title={nextCoin ? `Next: ${nextCoin.symbol}` : 'Next coin'}
        className="absolute right-2 top-1/2 -translate-y-1/2 z-20 group flex items-center gap-1.5 p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 shadow-xl backdrop-blur-md transition-all active:scale-95 cursor-pointer"
      >
        {nextCoin && (
          <div className="hidden sm:flex flex-col text-right text-[11px] leading-tight">
            <span className="font-bold text-white">{nextCoin.baseAsset}</span>
            <span
              className={`text-[10px] font-mono ${
                (nextTicker?.priceChangePercent ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {(nextTicker?.priceChangePercent ?? 0) >= 0 ? '+' : ''}
              {nextTicker?.priceChangePercent?.toFixed(1) ?? '0.0'}%
            </span>
          </div>
        )}
        <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
      </button>

      {/* Bottom Interactive Swipe Strip & Progress Bar */}
      {/* This strip receives touch events even when the iframe is active! */}
      <div
        id="touch-swipe-zone"
        {...touchHandlers}
        className="absolute bottom-0 inset-x-0 z-20 bg-gradient-to-t from-[#090d16] via-[#090d16]/90 to-transparent pt-3 pb-2 px-4 select-none touch-pan-x"
      >
        <div className="max-w-md mx-auto flex items-center justify-between gap-3 bg-slate-900/90 border border-slate-800/90 rounded-full py-1.5 px-3 shadow-lg backdrop-blur-md">
          {/* Quick prev button */}
          <button
            onClick={onPrev}
            className="p-1 rounded-full text-slate-400 hover:text-white active:scale-90 transition cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Swipe Indicator & Progress */}
          <div className="flex-1 flex flex-col items-center">
            <div className="flex items-center gap-2 text-xs text-slate-300 font-medium">
              <Hand className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>Swipe anywhere or tap sides</span>
              <span className="font-mono text-emerald-400 font-semibold">
                {currentIndex + 1}/{totalCoins}
              </span>
            </div>
            {/* Progress dot bar */}
            <div className="w-28 bg-slate-800 h-1 rounded-full overflow-hidden mt-1">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                style={{
                  width: `${((currentIndex + 1) / totalCoins) * 100}%`,
                }}
              />
            </div>
          </div>

          {/* Quick next button */}
          <button
            onClick={onNext}
            className="p-1 rounded-full text-slate-400 hover:text-white active:scale-90 transition cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </>
  );
};
