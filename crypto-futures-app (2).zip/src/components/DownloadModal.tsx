import React, { useState } from 'react';
import { Download, Smartphone, Copy, Check, X, FileArchive, Terminal, HelpCircle } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedAide, setCopiedAide] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    setDownloading(true);
    const link = document.createElement('a');
    link.href = '/crypto-futures-app.zip';
    link.download = 'crypto-futures-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => {
      setDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    }, 800);
  };

  const aideCode = `package com.cryptofutures.chart;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("${window.location.origin}");
        setContentView(webView);
    }
}`;

  const copyAideCode = () => {
    navigator.clipboard.writeText(aideCode);
    setCopiedAide(true);
    setTimeout(() => setCopiedAide(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-lg max-h-[92vh] flex flex-col bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Download App & APK Guide</h3>
              <p className="text-xs text-slate-400">ਫ਼ੋਨ 'ਤੇ ਇੰਸਟਾਲ ਕਰੋ ਜਾਂ AIDE ਲਈ APK ਕੋਡ ਪ੍ਰਾਪਤ ਕਰੋ</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Method 1: Instant Phone Install (PWA) */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/40 to-slate-900 border border-emerald-500/30 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-white text-sm">ਤਰੀਕਾ 1: ਫ਼ੋਨ 'ਤੇ ਸਿੱਧਾ Install ਕਰੋ (No AIDE Needed)</span>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                1 Tap Install
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              ਇਹ ਐਪ ਪੂਰੀ ਤਰ੍ਹਾਂ PWA ਹੈ। ਇਸਨੂੰ ਇੰਸਟਾਲ ਕਰਨ ਨਾਲ ਬਿਲਕੁਲ APK ਵਾਂਗ ਤੁਹਾਡੇ ਫ਼ੋਨ ਦੀ ਹੋਮ ਸਕ੍ਰੀਨ 'ਤੇ ਆਈਕਨ ਬਣ ਜਾਵੇਗਾ ਅਤੇ ਫੁੱਲ-ਸਕ੍ਰੀਨ ਚੱਲੇਗੀ।
            </p>

            {isInstalled ? (
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>ਤੁਹਾਡੇ ਫ਼ੋਨ 'ਤੇ ਪਹਿਲਾਂ ਹੀ ਇੰਸਟਾਲ ਹੈ!</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={install}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>ਹੁਣੇ ਫ਼ੋਨ 'ਤੇ Install ਕਰੋ</span>
              </button>
            ) : (
              <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-1.5">
                <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Chrome ਵਿੱਚ Install ਕਰਨ ਦਾ ਤਰੀਕਾ:</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px]">
                  <li>Chrome ਵਿੱਚ ਉੱਪਰ ਸੱਜੇ ਪਾਸੇ <strong className="text-white">3 ਬਿੰਦੂਆਂ (⋮)</strong> 'ਤੇ ਟੈਪ ਕਰੋ</li>
                  <li><strong className="text-emerald-400">"Install app"</strong> ਜਾਂ <strong className="text-emerald-400">"Add to Home screen"</strong> ਦਬਾਓ</li>
                  <li>ਹੋਮ ਸਕ੍ਰੀਨ 'ਤੇ ਅਸਲੀ ਐਪ ਆਈਕਨ ਬਣ ਜਾਵੇਗਾ</li>
                </ol>
              </div>
            )}
          </div>

          {/* Method 2: Android AIDE Code for APK */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-cyan-400" />
                <span className="font-bold text-white text-sm">ਤਰੀਕਾ 2: Android AIDE ਵਿੱਚ APK ਬਣਾਓ</span>
              </div>
              <button
                onClick={copyAideCode}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-semibold transition cursor-pointer"
              >
                {copiedAide ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>ਕੋਡ ਕਾਪੀ ਹੋ ਗਿਆ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Java Code</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-xs text-slate-300">
              ਜਿਵੇਂ ਤੁਸੀਂ ਕਿਹਾ ਸੀ ਕਿ ਤੁਸੀਂ Android AIDE ਵਿੱਚ APK ਬਣਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ:
            </p>
            <ol className="list-decimal list-inside text-slate-400 text-[11px] space-y-1 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/80">
              <li>Android AIDE ਵਿੱਚ ਨਵਾਂ ਪ੍ਰੋਜੈਕਟ ਬਣਾਓ: <strong>"Android App"</strong></li>
              <li><code className="text-cyan-300 font-mono">AndroidManifest.xml</code> ਵਿੱਚ <code className="text-amber-300 font-mono">&lt;uses-permission android:name="android.permission.INTERNET" /&gt;</code> ਲਿਖੋ</li>
              <li><code className="text-cyan-300 font-mono">MainActivity.java</code> ਵਿੱਚ ਹੇਠਾਂ ਦਿੱਤਾ ਕੋਡ ਪੇਸਟ ਕਰੋ:</li>
            </ol>

            <pre className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[10px] font-mono text-cyan-200 overflow-x-auto max-h-36">
              {aideCode}
            </pre>

            <p className="text-[11px] text-emerald-400 font-medium">
              ਫਿਰ AIDE ਵਿੱਚ "Run" ਬਟਨ ਦਬਾਓ — ਤੁਹਾਡੇ ਫ਼ੋਨ 'ਤੇ ਸਿੱਧੀ .APK ਫ਼ਾਈਲ ਇੰਸਟਾਲ ਹੋ ਜਾਵੇਗੀ!
            </p>
          </div>

          {/* Method 3: Download Complete Source Code (.ZIP) */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileArchive className="w-5 h-5 text-amber-400" />
                <span className="font-bold text-white text-sm">ਤਰੀਕਾ 3: ਪੂਰਾ ਕੋਡ (.ZIP) ਡਾਊਨਲੋਡ ਕਰੋ</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                crypto-futures-app.zip
              </span>
            </div>

            <p className="text-xs text-slate-400">
              ਸਾਰਾ React, Tailwind, 200+ CoinDCX Futures ਕੋਇਨ ਡੇਟਾ ਅਤੇ AIDE ਗਾਈਡ ਵਾਲੀ ZIP ਫ਼ਾਈਲ ਡਾਊਨਲੋਡ ਕਰੋ।
            </p>

            <button
              id="btn-download-project-zip"
              onClick={handleDownloadZip}
              disabled={downloading}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-98 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'ਡਾਊਨਲੋਡ ਹੋ ਰਿਹਾ ਹੈ...' : 'Download Project (.ZIP)'}</span>
            </button>

            {downloadSuccess && (
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold justify-center">
                <Check className="w-3.5 h-3.5" />
                <span>ZIP ਫ਼ਾਈਲ ਤੁਹਾਡੇ ਫ਼ੋਨ 'ਚ ਡਾਊਨਲੋਡ ਹੋ ਗਈ ਹੈ!</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition cursor-pointer"
          >
            ਬੰਦ ਕਰੋ (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
