import React, { useState, useEffect, useRef } from 'react';
import { CryptoCoin, TickerData, TimeframeId } from '../types';
import { TIMEFRAMES } from '../data/coins';
import {
  Star,
  Search,
  SlidersHorizontal,
  Play,
  Square,
  TrendingUp,
  TrendingDown,
  Copy,
  Check,
  Zap,
} from 'lucide-react';

interface HeaderTickerProps {
  coin: CryptoCoin;
  ticker?: TickerData;
  timeframe: TimeframeId;
  onSelectTimeframe: (tf: TimeframeId) => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onOpenDrawer: () => void;
  onOpenFavorites?: () => void;
  favoritesCount?: number;
  currentIndex: number;
  totalCoins: number;
  isAutoScanActive: boolean;
  onToggleAutoScan: () => void;
  autoScanSecondsLeft?: number;
}

export const HeaderTicker: React.FC<HeaderTickerProps> = ({
  coin,
  ticker,
  timeframe,
  onSelectTimeframe,
  isFavorite,
  onToggleFavorite,
  onOpenDrawer,
  onOpenFavorites,
  favoritesCount = 0,
  currentIndex,
  totalCoins,
  isAutoScanActive,
  onToggleAutoScan,
  autoScanSecondsLeft,
}) => {
  const [copied, setCopied] = useState(false);
  const [priceFlash, setPriceFlash] = useState<'up' | 'down' | null>(null);
  const prevPriceRef = useRef<number | null>(null);

  // Detect price tick up/down
  useEffect(() => {
    if (ticker?.lastPrice) {
      if (prevPriceRef.current !== null && prevPriceRef.current !== ticker.lastPrice) {
        if (ticker.lastPrice > prevPriceRef.current) {
          setPriceFlash('up');
        } else {
          setPriceFlash('down');
        }
        const timer = setTimeout(() => setPriceFlash(null), 600);
        return () => clearTimeout(timer);
      }
      prevPriceRef.current = ticker.lastPrice;
    }
  }, [ticker?.lastPrice]);

  const copyCoinDCXSymbol = () => {
    navigator.clipboard?.writeText(coin.coindcxPair);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isPositive = (ticker?.priceChangePercent ?? 0) >= 0;

  // Format price based on coin value
  const formatPrice = (val?: number) => {
    if (val === undefined || val === null || isNaN(val)) return '---';
    if (val < 0.001) return val.toFixed(coin.precision || 6);
    if (val < 1) return val.toFixed(4);
    if (val < 10) return val.toFixed(3);
    return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Format volume (e.g. 1.2M, 500K)
  const formatVolume = (val?: number) => {
    if (!val) return '---';
    if (val >= 1_000_000_000) return `${(val / 1_000_000_000).toFixed(2)}B`;
    if (val >= 1_000_000) return `${(val / 1_000_000).toFixed(2)}M`;
    if (val >= 1_000) return `${(val / 1_000).toFixed(1)}K`;
    return val.toFixed(0);
  };

  // Price range percentage between 24h Low and High
  const high = ticker?.highPrice || 0;
  const low = ticker?.lowPrice || 0;
  const curr = ticker?.lastPrice || 0;
  const rangePct = high > low && curr >= low ? Math.min(100, Math.max(0, ((curr - low) / (high - low)) * 100)) : 50;

  return (
    <header className="bg-[#0b1120] border-b border-slate-800/80 px-2 sm:px-4 py-2 select-none shrink-0 z-30">
      {/* Top Bar: Coin Details & Live Price */}
      <div className="flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
        {/* Coin Identity & Star */}
        <div className="flex items-center gap-2 min-w-0">
          <button
            id="btn-toggle-favorite"
            onClick={onToggleFavorite}
            title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            className="p-1 rounded-md text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
          >
            <Star
              className={`w-4 h-4 sm:w-5 sm:h-5 ${
                isFavorite ? 'fill-amber-400 text-amber-400' : 'text-slate-500'
              }`}
            />
          </button>

          <button
            id="btn-open-coins-drawer"
            onClick={onOpenDrawer}
            className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 transition group text-left cursor-pointer"
          >
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm sm:text-base text-white tracking-wide">
                  {coin.baseAsset}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">/USDT</span>
                <span className="px-1.5 py-0.2 text-[9px] font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">
                  Futures
                </span>
              </div>
              <span className="text-[11px] text-slate-400 truncate max-w-[110px] sm:max-w-none">
                {coin.name} &bull; #{currentIndex + 1}/{totalCoins}
              </span>
            </div>
            <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-400 transition-colors ml-1" />
          </button>

          {/* CoinDCX contract badge with one-click copy */}
          <button
            onClick={copyCoinDCXSymbol}
            title="CoinDCX Futures Contract (click to copy)"
            className="hidden md:flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-950/40 text-blue-300 border border-blue-800/40 text-[10px] hover:bg-blue-900/50 transition cursor-pointer"
          >
            <span>CoinDCX:</span>
            <span className="font-mono font-semibold">{coin.coindcxPair}</span>
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-blue-400" />}
          </button>
        </div>

        {/* Live Real-Time Price & 24h Change */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="text-right">
            <div
              className={`font-mono font-bold text-sm sm:text-lg transition-colors duration-300 ${
                priceFlash === 'up'
                  ? 'text-emerald-400 scale-105'
                  : priceFlash === 'down'
                  ? 'text-rose-400 scale-105'
                  : 'text-white'
              }`}
            >
              ${formatPrice(ticker?.lastPrice)}
            </div>
            <div className="flex items-center justify-end gap-1 text-[11px] font-mono">
              <span
                className={`flex items-center font-semibold ${
                  isPositive ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {isPositive ? (
                  <TrendingUp className="w-3 h-3 mr-0.5" />
                ) : (
                  <TrendingDown className="w-3 h-3 mr-0.5" />
                )}
                {isPositive ? '+' : ''}
                {ticker?.priceChangePercent?.toFixed(2) ?? '0.00'}%
              </span>
            </div>
          </div>

          {/* 24h High / Low & Volume (Desktop & Tablet) */}
          <div className="hidden lg:flex flex-col text-[11px] font-mono text-slate-400 border-l border-slate-800 pl-3">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">24h H:</span>
              <span className="text-slate-200">${formatPrice(high)}</span>
              <span className="text-slate-500 ml-2">24h L:</span>
              <span className="text-slate-200">${formatPrice(low)}</span>
            </div>
            {/* Range bar */}
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1 flex">
              <div
                className="bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-500 h-full transition-all duration-500"
                style={{ width: `${rangePct}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-500 mt-0.5">
              <span>Vol: ${formatVolume(ticker?.quoteVolume)}</span>
              <span>Range: {rangePct.toFixed(0)}%</span>
            </div>
          </div>

          {/* Quick Actions: Auto-Scan & Coin List Drawer */}
          <div className="flex items-center gap-1">
            <button
              id="btn-auto-scan"
              onClick={onToggleAutoScan}
              title={isAutoScanActive ? 'Stop Auto-Scanning charts' : 'Start Auto-Scanning charts hands-free'}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium border transition cursor-pointer ${
                isAutoScanActive
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                  : 'bg-slate-900 text-slate-300 border-slate-700/60 hover:bg-slate-800'
              }`}
            >
              {isAutoScanActive ? (
                <>
                  <Square className="w-3 h-3 text-amber-400 fill-amber-400" />
                  <span className="hidden sm:inline">Auto-Scan</span>
                  <span className="font-mono font-bold text-amber-300">{autoScanSecondsLeft}s</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 text-slate-400" />
                  <span className="hidden sm:inline">Auto-Scan</span>
                </>
              )}
            </button>

            {/* Watchlist / Favorites button */}
            {onOpenFavorites && (
              <button
                id="btn-open-watchlist"
                onClick={onOpenFavorites}
                title="View your Starred Favorites list"
                className="flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/35 text-xs font-semibold shadow-xs transition cursor-pointer"
              >
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span className="hidden sm:inline">Watchlist</span>
                <span className="bg-amber-500/30 px-1 rounded text-[10px] font-mono text-amber-200">
                  {favoritesCount}
                </span>
              </button>
            )}

            <button
              id="btn-open-coins-list"
              onClick={onOpenDrawer}
              title="All Coins & Filters"
              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition cursor-pointer"
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span className="hidden xs:inline">Coins</span>
              <span className="bg-emerald-700/80 px-1 rounded text-[10px] font-mono">
                {totalCoins}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Timeframe Bar */}
      <div className="flex items-center justify-between gap-1 mt-1.5 pt-1.5 border-t border-slate-800/60 overflow-x-auto">
        <div className="flex items-center gap-1 shrink-0">
          <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mr-1 hidden sm:inline">
            Timeframe:
          </span>
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf.id}
              onClick={() => onSelectTimeframe(tf.id)}
              className={`px-2 py-0.5 rounded text-xs font-mono font-medium transition cursor-pointer ${
                timeframe === tf.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
              }`}
            >
              {tf.label}
            </button>
          ))}
        </div>

        {/* Swipe Hint Pill */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium shrink-0 ml-2">
          <span className="hidden md:inline-flex items-center gap-1 text-[10px] text-slate-400">
            <span className="px-1 py-0.2 bg-slate-800 rounded border border-slate-700 text-slate-300 font-mono">←</span>
            <span className="px-1 py-0.2 bg-slate-800 rounded border border-slate-700 text-slate-300 font-mono">→</span>
            Swipe or Arrow Keys
          </span>
          <span className="md:hidden flex items-center gap-1 text-emerald-400/90 text-[10px]">
            <Zap className="w-3 h-3" />
            Swipe left/right to change
          </span>
        </div>
      </div>
    </header>
  );
};
